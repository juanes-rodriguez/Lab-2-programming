
package concesionario;

public class carssale {
     
    //cantCarros se va a llenar en funcion del click en el botón OK 
    int cantCars = 0;    
    arreglos carros [] = new arreglos [cantCars];

    
    void bubbleSort(float array[])
    {
        for (int i = 0; i < array.length-1; i++){
            for (int j = 0; j < array.length- 1; j++){
                if (array[j] > array[j + 1]) {
                    // swap arr[j+1] and arr[j]
                    int valorTemp = (int)array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = valorTemp;
                }
            }
        }
    }

     void merge(float array[], int izq, int mitad, int der)
    {
     
        
        int primeraMitad = mitad - izq + 1;
        int segundaMitad = der - mitad;
  
     
        int izquierda[] = new int[primeraMitad];
        int derecha[] = new int[segundaMitad];
        
        for (int i = 0; i < primeraMitad; ++i)
            izquierda[i] = (int)array[izq + i];
        for (int j = 0; j < segundaMitad; ++j)
            derecha[j] = (int)array[mitad + 1 + j];
  
       
        int i = 0, j = 0;
        
        int inicial = izq;
        while (i < primeraMitad && j < segundaMitad) {
            if (izquierda[i] <= derecha[j]) {
                array[inicial] = izquierda[i];
                i++;
            }
            else {
                array[inicial] = derecha[j];
                j++;
            }
            inicial++;
        }
        
        while (i < primeraMitad) {
            array[inicial] = izquierda[i];
            i++;
            inicial++;
        }
        
        while (j < segundaMitad) {
            array[inicial] = derecha[j];
            j++;
            inicial++;
        }

       
    }
 
    void sort(float array[], int izq, int der)
    {
        
        if (izq < der) {
           
            int m = izq + (der- izq) / 2;
            sort(array, izq, m);
            sort(array, m + 1, der);
            merge(array, izq, m, der);
        }
 
    }
}
