
package concesionario;


public class arreglos {
    
    int cars = 0;
    float [] kilometraje = new float[cars]; 
    float [] modelo = new float[cars];
    String color;
    String marca;
    
    
    public arreglos(float[] fast, float[] model, String color, String brand ){
        this.kilometraje = fast; 
        this.modelo = model; 
        this.color = color; 
        this.marca = brand; 
    }

    public float[] getKilometraje() {
        return kilometraje;
    }

    public void setKilometraje(float[] kilometraje) {
        this.kilometraje = kilometraje;
    }

    public float[] getModelo() {
        return modelo;
    }

    public void setModelo(float[] modelo) {
        this.modelo = modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
    
  
    
}
